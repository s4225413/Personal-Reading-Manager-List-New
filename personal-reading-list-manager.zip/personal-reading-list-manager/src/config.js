export const SUPABASE_URL = 'https://xmugyhhsyojagbcetsat.supabase.co';
export const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhtdWd5aGhzeW9qYWdiY2V0c2F0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIwNzkyNTEsImV4cCI6MjA2NzY1NTI1MX0.6IYlkW6uadSroArKLf2ggplg4PUPkSiceUFF8-kh6gg';

export const TABLE_NAME = 'books';
export const DEFAULT_STATUSES = ['To Read', 'Reading', 'Completed'];
